import { BsDatepickerConfig } from 'ngx-bootstrap/datepicker';
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';

import { Employee } from './../model/employee.model';
import { Department } from '../model/department.model';
import { Education } from './../model/education.model';

@Component({
  selector: 'app-create-employee',
  templateUrl: './create-employee.component.html',
  styleUrls: ['./create-employee.component.scss']
})
export class CreateEmployeeComponent implements OnInit {
  datepickerConfig: Partial<BsDatepickerConfig>;
  showPreview = false;
  errorMessage = 'Please correct the fileds highlighted in red !';
  noerror = true;
  departments: Department[] = [
    { id: 1, name: 'Help Desk' },
    { id: 2, name: 'HR' },
    { id: 2, name: 'IT' },
    { id: 2, name: 'Payroll' }
  ];

  educations: Education[] = [
    { id: 1, name: 'M.Tech.' },
    { id: 2, name: 'B.Tech.' },
    { id: 2, name: 'Diploma' },
    { id: 2, name: 'Matric' }
  ];

  employee: Employee = {
    id: null,
    name: null,
    email: '',
    alternateEmail: '',
    gender: null,
    contactPreference: null,
    isActive: true,
    department: null,
    education: null,
    dateOfBirth: new Date()
  };
  constructor() {
    this.datepickerConfig = Object.assign({},
      {
        containerClass: 'theme-dark-blue',
        maxDate: new Date(),
        showWeekNumbers: false,
        dateInputFormat: 'DD/MM/YYYY'
      }
    );
  }

  togglePhotoPreview(): void {
    this.showPreview = !this.showPreview;
  }

  saveEmployee(employeeForm: NgForm): void {
    if ( employeeForm.valid ) {
      this.noerror = true;
      this.errorMessage = null;
      console.log(JSON.stringify(this.employee));
    } else {
      this.noerror = false;
      this.errorMessage = 'Please correct the fileds highlighted in red !';
    }
  }

  ngOnInit() {
  }

}
