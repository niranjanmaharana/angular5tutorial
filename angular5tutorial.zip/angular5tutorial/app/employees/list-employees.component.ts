import { Education } from './../model/education.model';
import { Department } from './../model/department.model';
import { Employee } from '../model/employee.model';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-list-employees',
  templateUrl: './list-employees.component.html',
  styleUrls: ['./list-employees.component.scss']
})
export class ListEmployeesComponent implements OnInit {
  departments: Department[] = [
    { id: 1, name: 'Help Desk' },
    { id: 2, name: 'HR' },
    { id: 2, name: 'IT' },
    { id: 2, name: 'Payroll' }
  ];

  educations: Education[] = [
    { id: 1, name: 'M.Tech.' },
    { id: 2, name: 'B.Tech.' },
    { id: 2, name: 'Diploma' },
    { id: 2, name: 'Matric' }
  ];

  employees: Employee[] = [{
      id: 101,
      name: 'Niranjan Maharana',
      gender: 'male',
      email: 'niranjan.m@rxprism.com',
      phoneNumber: 9556824846,
      contactPreference: 'email',
      dateOfBirth: new Date(1993, 4, 26),
      department: 3,
      education: 1,
      isActive: true,
      photoPath: 'assets/images/male.png'
    }, {
      id: 102,
      name: 'Anonymous Maharana',
      gender: 'female',
      email: 'anonymous.m@rxprism.com',
      phoneNumber: 9337079036,
      contactPreference: 'phone',
      dateOfBirth: new Date(1995, 6, 2),
      department: 3,
      education: 2,
      isActive: false,
      photoPath: 'assets/images/female.png'
    }
  ];

  constructor() { }

  ngOnInit() {
  }
}
