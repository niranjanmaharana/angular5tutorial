export class Education {
  id: number;
  name: string;
}
